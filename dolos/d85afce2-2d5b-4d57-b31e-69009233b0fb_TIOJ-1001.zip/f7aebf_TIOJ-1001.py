a="Hello Tmt World XD!"
print("Hello Tmt World XD!")