def is_twin_prime(x, y):
    # 判斷兩個數字是否是孿生質數
    return abs(x - y) == 2 and (is_prime(x) and is_prime(y))


def is_prime(n):
    # 判斷一個數字是否是質數
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True


test_cases = int(input())  # 讀取測試資料組數

for _ in range(test_cases):
    nums = input().split(',')  # 讀取每組測試資料的數字
    x = int(nums[0])
    y = int(nums[1])

    if is_twin_prime(x, y):
        print("Y")  # 是孿生質數
    else:
        print("N")  # 不是孿生質數
