'''x = input()
print(x)'''

'''a = 0
x = int(input())
for i in range(x+1):
    a+=i
print(a)'''

'''x = []
nums = list(map(int,input().split()))
while True:
    for i in nums:
        y = int(i)
        y += 1
        x.append(y)
print(x)'''

'''numbers = input().split()  

result = []  

for num in numbers:
    num = int(num)  
    num += 1  
    result.append(str(num))  

output = ' '.join(result)  

print(output)'''  

'''def fibonacci_nth(n):
    if n <= 0:
        return None
    elif n == 1:
        return 0
    elif n == 2:
        return 1
    else:
        a, b = 0, 1
        for _ in range(3, n + 1):
            a, b = b, a + b
        return b

i = int(input())

result = fibonacci_nth(i)

print(result)'''

'''def x(a, b):
    c = set(a) & set(b) 

    if len(c) >= 3:
        if len(c) == 3:
            return 100
        elif len(c) == 4:
            return 1000
        else:
            return 10000

    return 0


gg = input()
a, b = gg.split(",")

a = list(map(int,a.split()))
b = list(map(int,b.split()))

p = x(a,b)

print(p)'''

'''c =[]
x = int(input())
for i in range(x):
    a,b = map(int,input().split())

    if a > b:
        c.append('>')
    elif a < b:
        c.append('<')
    else:
        c.append('=')
for j in c:
    print(j)'''

'''x = []

while True:
    try:
        a,b,c = map(int,input().split())
        d = a+b;e = b+c
        if d > e:
            x.append('>')
        elif d < e:
            x.append('<')
        else:
            x.append('=')

    except EOFError:
        break

for j in x:
    print(j)'''

'''ero = list(map(int,input().split())) 
order = str(input())  
g = sum(ero)-max(ero)-min(ero)

if order == 'ABC':
    print(min(ero),g,max(ero))
elif order == 'ACB':
    print(min(ero),max(ero),g)
elif order == 'BAC':
    print(g,min(ero),max(ero))
elif order == 'BCA':
    print(g,max(ero),min(ero))
elif order == 'CAB':
    print(max(ero),min(ero),g)
elif order == 'CBA':
    print(max(ero),g,min(ero))'''

#no
'''data = []
while True:
    n = int(input())
    if n == 0:
        break
    group = [input() for _ in range(n)]
    data.append(group)

for group in data:
    print(len(group))
    print(' '.join(group))'''

'''y = []
x = int(input())
for i in range(x):
    a = int(input())
    gg = bin(a)[2:]
    b = gg.count('1')
    y.append(b)

for j in y:
    print(j)'''

def p(number):
    if number < 2:
        return False
    for i in range(2, int(number**0.5) + 1):
        if number % i == 0:
            return False
    return True
g = []
x = int(input())
for i in range(x):
    a,b = map(int,input().split(','))
    c = b - a
    if c == 2:
        if p(a) and p(b):
            g.append('Y')
        else:
            g.append('N')
    else:
        g.append('N')

for h in g:
    print(h)
    
