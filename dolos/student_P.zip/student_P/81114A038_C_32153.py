def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def is_twin_prime(x, y):
    if is_prime(x) and is_prime(y) and abs(x - y) == 2:
        return "Y"
    else:
        return "N"


n = int(input())

for _ in range(n):
    x, y = map(int, input().split(','))
    result = is_twin_prime(x, y)
    print(result)
