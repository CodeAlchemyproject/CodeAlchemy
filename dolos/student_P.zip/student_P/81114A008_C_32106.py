n = int(input())
for _ in range(n):
    x, y = map(int, input().split(','))
    is_x_prime = True
    is_y_prime = True
    for i in range(2, x):
        if x % i == 0:
            is_x_prime = False
            break
    for i in range(2, y):
        if y % i == 0:
            is_y_prime = False
            break
    if is_x_prime and is_y_prime and abs(x - y) == 2:
        print("Y")
    else:
        print("N")