n = int(input())
for i in range(n):
    a,b = map(int,input().split(','))
    if b - a != 2:
        print('N')
    else:
        prime = True
        for i in range(2,int(b**0.5+1)):
            if a % i == 0 or b % i == 0:
                prime = False
                break
        if prime:
            print('Y')
        else:
            print('N')
