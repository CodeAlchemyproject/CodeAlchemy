def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def is_twin_primes(n1, n2):
    if is_prime(n1) and is_prime(n2) and abs(n1 - n2) == 2:
        return "Y"
    else:
        return "N"

num_tests = int(input())

results = []

for _ in range(num_tests):
    nums = input().split(",")
    n1, n2 = map(int, nums)
    result = is_twin_primes(n1, n2)
    results.append(result)

for result in results:
    print(result)
