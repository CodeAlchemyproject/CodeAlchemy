str="Hello Tmt World XD!"
print(str)